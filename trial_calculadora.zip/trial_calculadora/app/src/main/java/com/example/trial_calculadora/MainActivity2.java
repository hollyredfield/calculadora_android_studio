package com.example.trial_calculadora;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;

public class MainActivity2 extends AppCompatActivity {

    private Button[] buttons = new Button[16];
    private TextView display;
    private String currentOperator = "";
    private double firstOperand = Double.NaN;
    private double secondOperand;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize the TextView
        display = findViewById(R.id.textView3);

        // Initialize the buttons
        buttons[0] = findViewById(R.id.b7);
        buttons[1] = findViewById(R.id.b8);
        buttons[2] = findViewById(R.id.b9);
        buttons[3] = findViewById(R.id.bdiv);
        buttons[4] = findViewById(R.id.b4);
        buttons[5] = findViewById(R.id.b5);
        buttons[6] = findViewById(R.id.b6);
        buttons[7] = findViewById(R.id.bx);
        buttons[8] = findViewById(R.id.b1);
        buttons[9] = findViewById(R.id.b2);
        buttons[10] = findViewById(R.id.b3);
        buttons[11] = findViewById(R.id.bless);
        buttons[12] = findViewById(R.id.b0);
        buttons[13] = findViewById(R.id.bdot);
        buttons[14] = findViewById(R.id.bequal);
        buttons[15] = findViewById(R.id.bplus);

        // Set click listeners for the buttons
        for (Button button : buttons) {
            button.setOnClickListener(this::onButtonClick);
        }
    }

    private void onButtonClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();

        switch (buttonText) {
            case "+":
            case "-":
            case "*":
            case "/":
                handleOperator(buttonText);
                break;
            case "=":
                handleEqual();
                break;
            case ".":
                handleDot();
                break;
            default:
                handleNumber(buttonText);
                break;
        }
    }

    private void handleOperator(String operator) {
        if (!Double.isNaN(firstOperand)) {
            secondOperand = Double.parseDouble(display.getText().toString());
            firstOperand = performOperation(firstOperand, secondOperand, currentOperator);
            display.setText(String.valueOf(firstOperand));
        } else {
            firstOperand = Double.parseDouble(display.getText().toString());
        }
        currentOperator = operator;
        display.setText("");
    }

    private void handleEqual() {
        if (!Double.isNaN(firstOperand)) {
            secondOperand = Double.parseDouble(display.getText().toString());
            double result = performOperation(firstOperand, secondOperand, currentOperator);
            display.setText(String.valueOf(result));
            firstOperand = Double.NaN;
            currentOperator = "";
        }
    }

    private void handleDot() {
        if (!display.getText().toString().contains(".")) {
            display.append(".");
        }
    }

    private void handleNumber(String number) {
        display.append(number);
    }

    private double performOperation(double firstOperand, double secondOperand, String operator) {
        switch (operator) {
            case "+":
                return firstOperand + secondOperand;
            case "-":
                return firstOperand - secondOperand;
            case "*":
                return firstOperand * secondOperand;
            case "/":
                if (secondOperand != 0) {
                    return firstOperand / secondOperand;
                } else {
                    display.setText("Error");
                    return Double.NaN;
                }
            default:
                return secondOperand;
        }
    }
}